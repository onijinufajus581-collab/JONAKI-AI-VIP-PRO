package com.jonaki.ai;
import android.Manifest; import android.app.Activity; import android.content.*; import android.content.pm.PackageManager;
import android.graphics.Color; import android.graphics.Typeface; import android.graphics.drawable.GradientDrawable;
import android.os.Bundle; import android.speech.*; import android.speech.tts.TextToSpeech; import android.view.Gravity;
import android.view.animation.ScaleAnimation; import android.widget.*; import java.util.*;
public class MainActivity extends Activity {
 private TextToSpeech tts; private SpeechRecognizer sr; private TextView status, transcript;
 private int dp(float x){return (int)(x*getResources().getDisplayMetrics().density+.5f);}
 private GradientDrawable shape(int c,int s){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(dp(20));d.setStroke(dp(1),s);return d;}
 private TextView label(String s,int z,int c,boolean b){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);t.setGravity(Gravity.CENTER);t.setTypeface(Typeface.DEFAULT,b?1:0);return t;}
 private Button btn(String s,int c){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(16);b.setTypeface(null,1);b.setBackground(shape(c,0xff00e5ff));return b;}
 public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(0xff080914);getWindow().setNavigationBarColor(0xff080914);ui();tts=new TextToSpeech(this,r->{if(r==0){int l=tts.setLanguage(new Locale("bn","BD"));if(l<0)tts.setLanguage(Locale.US);tts.setSpeechRate(.94f);say("Hello Sir, আমি Jonaki. কীভাবে সাহায্য করতে পারি?");}});}
 private void ui(){
  ScrollView sc=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(1);root.setGravity(Gravity.CENTER_HORIZONTAL);root.setPadding(dp(22),dp(28),dp(22),dp(28));
  root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xff080914,0xff1b1034,0xff071b2b}));sc.addView(root);setContentView(sc);
  TextView logo=label("✧",60,0xff00e5ff,true);logo.setBackground(shape(0xff17132e,0xff9b72ff));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(112),dp(112));lp.bottomMargin=dp(16);root.addView(logo,lp);
  ScaleAnimation pulse=new ScaleAnimation(.94f,1.04f,.94f,1.04f,1, .5f,1,.5f);pulse.setDuration(900);pulse.setRepeatMode(2);pulse.setRepeatCount(-1);logo.startAnimation(pulse);
  root.addView(label("JONAKI AI VIP",28,Color.WHITE,true));root.addView(label("YOUR FEMININE VOICE ASSISTANT",11,0xff00e5ff,true));
  LinearLayout card=new LinearLayout(this);card.setOrientation(1);card.setPadding(dp(18),dp(22),dp(18),dp(20));card.setBackground(shape(0xff17172b,0xff6749a9));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.topMargin=dp(25);root.addView(card,cp);
  card.addView(label("Hello! আমি Jonaki.",22,Color.WHITE,true));card.addView(label("নিচের Listen বাটনে চাপ দিয়ে কথা বলো।",14,0xffd5d1e9,false));
  status=label("● READY",13,0xff48f0c4,true);card.addView(status);transcript=label("তোমার কথা এখানে দেখা যাবে",14,0xffdedbed,false);transcript.setPadding(0,dp(18),0,dp(12));card.addView(transcript);
  Button listen=btn("🎙  START LISTENING",0xff5426a6);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(58));bp.topMargin=dp(18);card.addView(listen,bp);listen.setOnClickListener(v->listen());
  Button stop=btn("■  STOP",0xff39253e);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(54));sp.topMargin=dp(10);card.addView(stop,sp);stop.setOnClickListener(v->{destroyRecognizer();status.setText("● STOPPED");say("Listening বন্ধ করা হয়েছে");});
  LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);hp.topMargin=dp(24);root.addView(label("VOICE COMMANDS",14,0xff00e5ff,true),hp);
  TextView help=label("সময় বলো • YouTube খোলো • Facebook খোলো • Telegram খোলো • Play Store খোলো • Hello বলো",13,0xffd5d1e9,false);help.setPadding(dp(10),dp(14),dp(10),dp(14));help.setBackground(shape(0xff17172b,0xff40345f));root.addView(help);
  root.addView(label("Voice quality depends on voices installed on your phone.",11,0xff9996ad,false));
 }
 private void say(String s){if(tts!=null)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jonaki");}
 private void listen(){if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},5);return;}startSpeech();}
 public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);if(r==5&&g.length>0&&g[0]==0)startSpeech();else status.setText("Microphone permission দরকার");}
 private void startSpeech(){
  if(!SpeechRecognizer.isRecognitionAvailable(this)){status.setText("Speech service পাওয়া যায়নি");Toast.makeText(this,"Google Speech Services enable করো",Toast.LENGTH_LONG).show();return;}
  destroyRecognizer();sr=SpeechRecognizer.createSpeechRecognizer(this);sr.setRecognitionListener(new RecognitionListener(){
   public void onReadyForSpeech(Bundle b){status.setText("● LISTENING");} public void onBeginningOfSpeech(){status.setText("● HEARING");} public void onRmsChanged(float x){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){status.setText("Processing...");}
   public void onError(int e){status.setText("আবার Listen চাপো (error "+e+")");destroyRecognizer();}
   public void onResults(Bundle b){ArrayList<String>a=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(a!=null&&!a.isEmpty())command(a.get(0));destroyRecognizer();}
   public void onPartialResults(Bundle b){} public void onEvent(int e,Bundle b){}
  });
  Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"bn-BD");i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE,"bn-BD");i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Jonaki-কে বলো...");sr.startListening(i);
 }
 private void command(String raw){String q=raw.toLowerCase(Locale.ROOT),a;
  transcript.setText("You: "+raw);
  if(q.contains("time")||q.contains("সময়")||q.contains("কটা"))a="এখন সময় "+java.text.DateFormat.getTimeInstance(3).format(new Date());
  else if(q.contains("youtube")){a="YouTube খুলছি";open("https://youtube.com");}
  else if(q.contains("facebook")){a="Facebook খুলছি";open("https://facebook.com");}
  else if(q.contains("telegram")){a="Telegram খুলছি";appOrWeb("org.telegram.messenger","https://telegram.org");}
  else if(q.contains("play store")||q.contains("প্লে স্টোর")){a="Play Store খুলছি";appOrWeb("com.android.vending","https://play.google.com/store");}
  else if(q.contains("hello")||q.contains("হ্যালো")||q.contains("হাই"))a="Hello! আমি Jonaki. কীভাবে সাহায্য করতে পারি?";
  else a="এই command এখনো শিখিনি। YouTube, Facebook, Telegram, Play Store অথবা সময় বলো।";
  transcript.setText("You: "+raw+"\n\nJonaki: "+a);status.setText("● READY");say(a);
 }
 private void open(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,android.net.Uri.parse(u)));}catch(Exception e){status.setText("Browser পাওয়া যায়নি");}}
 private void appOrWeb(String p,String u){Intent i=getPackageManager().getLaunchIntentForPackage(p);if(i!=null)startActivity(i);else open(u);}
 private void destroyRecognizer(){if(sr!=null){try{sr.cancel();sr.destroy();}catch(Exception e){}sr=null;}}
 protected void onDestroy(){destroyRecognizer();if(tts!=null){tts.stop();tts.shutdown();}super.onDestroy();}
}
